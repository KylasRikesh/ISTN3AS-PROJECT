﻿Public Class AppointmentDetails
    Private Sub MaskedTextBox1_MouseHover(sender As Object, e As EventArgs)

    End Sub

    Private Sub AppointmentDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class