﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Customer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Customer))
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTextBox7 = New MetroFramework.Controls.MetroTextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New Guna.UI.WinForms.GunaGroupBox()
        Me.btnNext2 = New Guna.UI.WinForms.GunaCircleButton()
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.MaskedTextBox3 = New System.Windows.Forms.MaskedTextBox()
        Me.BunifuTextbox4 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuTextbox3 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.GroupBox1 = New Guna.UI.WinForms.GunaGroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BunifuTextbox1 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BunifuTextbox2 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.btnNext = New Guna.UI.WinForms.GunaCircleButton()
        Me.GroupBox3 = New Guna.UI.WinForms.GunaGroupBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MaskedTextBox2 = New System.Windows.Forms.MaskedTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ZipCodeTextBox = New Bunifu.Framework.UI.BunifuTextbox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.provinceTextBox = New Bunifu.Framework.UI.BunifuTextbox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CityTextBox = New Bunifu.Framework.UI.BunifuTextbox()
        Me.AddressTextBox = New Bunifu.Framework.UI.BunifuTextbox()
        Me.btnPrevious = New Guna.UI.WinForms.GunaCircleButton()
        Me.GunaCircleButton2 = New Guna.UI.WinForms.GunaCircleButton()
        Me.btnPrevious2 = New Guna.UI.WinForms.GunaCircleButton()
        Me.GunaCircleButton1 = New Guna.UI.WinForms.GunaCircleButton()
        Me.GroupBox4 = New Guna.UI.WinForms.GunaGroupBox()
        Me.GunaCircleButton3 = New Guna.UI.WinForms.GunaCircleButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.BunifuTextbox5 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuTextbox6 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.GunaCircleButton4 = New Guna.UI.WinForms.GunaCircleButton()
        Me.cbxGender = New Bunifu.Framework.UI.BunifuDropdown()
        Me.GunaNumeric1 = New Guna.UI.WinForms.GunaNumeric()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Regular
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(150, 34)
        Me.MetroTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(1000, 700)
        Me.MetroTabControl1.Style = MetroFramework.MetroColorStyle.Green
        Me.MetroTabControl1.TabIndex = 1
        Me.MetroTabControl1.Theme = MetroFramework.MetroThemeStyle.Light
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.BackColor = System.Drawing.Color.White
        Me.MetroTabPage2.Controls.Add(Me.GunaCircleButton1)
        Me.MetroTabPage2.Controls.Add(Me.MetroTextBox7)
        Me.MetroTabPage2.Controls.Add(Me.Panel3)
        Me.MetroTabPage2.Controls.Add(Me.Panel4)
        Me.MetroTabPage2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroTabPage2.HorizontalScrollbarBarColor = True
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 10
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(992, 658)
        Me.MetroTabPage2.TabIndex = 3
        Me.MetroTabPage2.Text = "Existing Customer"
        Me.MetroTabPage2.Theme = MetroFramework.MetroThemeStyle.Light
        Me.MetroTabPage2.VerticalScrollbarBarColor = True
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 10
        '
        'MetroTextBox7
        '
        '
        '
        '
        Me.MetroTextBox7.CustomButton.Image = Nothing
        Me.MetroTextBox7.CustomButton.Location = New System.Drawing.Point(322, 2)
        Me.MetroTextBox7.CustomButton.Name = ""
        Me.MetroTextBox7.CustomButton.Size = New System.Drawing.Size(25, 25)
        Me.MetroTextBox7.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.MetroTextBox7.CustomButton.TabIndex = 1
        Me.MetroTextBox7.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.MetroTextBox7.CustomButton.UseSelectable = True
        Me.MetroTextBox7.CustomButton.Visible = False
        Me.MetroTextBox7.DisplayIcon = True
        Me.MetroTextBox7.FontSize = MetroFramework.MetroTextBoxSize.Tall
        Me.MetroTextBox7.Icon = CType(resources.GetObject("MetroTextBox7.Icon"), System.Drawing.Image)
        Me.MetroTextBox7.IconRight = True
        Me.MetroTextBox7.Lines = New String(-1) {}
        Me.MetroTextBox7.Location = New System.Drawing.Point(334, 214)
        Me.MetroTextBox7.MaxLength = 32767
        Me.MetroTextBox7.Name = "MetroTextBox7"
        Me.MetroTextBox7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.MetroTextBox7.PromptText = "Search Customer"
        Me.MetroTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.MetroTextBox7.SelectedText = ""
        Me.MetroTextBox7.SelectionLength = 0
        Me.MetroTextBox7.SelectionStart = 0
        Me.MetroTextBox7.ShortcutsEnabled = True
        Me.MetroTextBox7.Size = New System.Drawing.Size(350, 30)
        Me.MetroTextBox7.TabIndex = 10
        Me.MetroTextBox7.UseSelectable = True
        Me.MetroTextBox7.WaterMark = "Search Customer"
        Me.MetroTextBox7.WaterMarkColor = System.Drawing.Color.Gray
        Me.MetroTextBox7.WaterMarkFont = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Honeydew
        Me.Panel3.Location = New System.Drawing.Point(618, 1)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(378, 145)
        Me.Panel3.TabIndex = 9
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Honeydew
        Me.Panel4.Controls.Add(Me.PictureBox2)
        Me.Panel4.Location = New System.Drawing.Point(-5, 1)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(682, 145)
        Me.Panel4.TabIndex = 8
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Honeydew
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(420, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(175, 145)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.BackColor = System.Drawing.Color.White
        Me.MetroTabPage1.Controls.Add(Me.GroupBox3)
        Me.MetroTabPage1.Controls.Add(Me.GroupBox4)
        Me.MetroTabPage1.Controls.Add(Me.Panel2)
        Me.MetroTabPage1.Controls.Add(Me.Panel1)
        Me.MetroTabPage1.Controls.Add(Me.GroupBox2)
        Me.MetroTabPage1.Controls.Add(Me.PictureBox1)
        Me.MetroTabPage1.Controls.Add(Me.GroupBox1)
        Me.MetroTabPage1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroTabPage1.HorizontalScrollbarBarColor = True
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 10
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(992, 658)
        Me.MetroTabPage1.TabIndex = 2
        Me.MetroTabPage1.Text = "New Customer"
        Me.MetroTabPage1.VerticalScrollbarBarColor = True
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 10
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Honeydew
        Me.Panel2.Location = New System.Drawing.Point(448, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(545, 80)
        Me.Panel2.TabIndex = 6
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Honeydew
        Me.Panel1.Location = New System.Drawing.Point(-1, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(354, 80)
        Me.Panel1.TabIndex = 5
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Honeydew
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(353, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(95, 80)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.BaseColor = System.Drawing.Color.White
        Me.GroupBox2.BorderColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.BorderSize = 1
        Me.GroupBox2.Controls.Add(Me.btnNext2)
        Me.GroupBox2.Controls.Add(Me.MaskedTextBox1)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.MaskedTextBox3)
        Me.GroupBox2.Controls.Add(Me.BunifuTextbox4)
        Me.GroupBox2.Controls.Add(Me.BunifuTextbox3)
        Me.GroupBox2.Controls.Add(Me.btnPrevious)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.LineColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(185, 127)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(475, 428)
        Me.GroupBox2.TabIndex = 45
        Me.GroupBox2.Text = "Step 2/4"
        Me.GroupBox2.TextLocation = New System.Drawing.Point(10, 8)
        '
        'btnNext2
        '
        Me.btnNext2.AnimationHoverSpeed = 0.07!
        Me.btnNext2.AnimationSpeed = 0.03!
        Me.btnNext2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnNext2.BorderColor = System.Drawing.Color.Black
        Me.btnNext2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnNext2.FocusedColor = System.Drawing.Color.Empty
        Me.btnNext2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnNext2.ForeColor = System.Drawing.Color.White
        Me.btnNext2.Image = CType(resources.GetObject("btnNext2.Image"), System.Drawing.Image)
        Me.btnNext2.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnNext2.Location = New System.Drawing.Point(328, 274)
        Me.btnNext2.Name = "btnNext2"
        Me.btnNext2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnNext2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnNext2.OnHoverForeColor = System.Drawing.Color.White
        Me.btnNext2.OnHoverImage = Nothing
        Me.btnNext2.OnPressedColor = System.Drawing.Color.Black
        Me.btnNext2.Size = New System.Drawing.Size(105, 100)
        Me.btnNext2.TabIndex = 32
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MaskedTextBox1.BeepOnError = True
        Me.MaskedTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MaskedTextBox1.ForeColor = System.Drawing.Color.Gray
        Me.MaskedTextBox1.HidePromptOnLeave = True
        Me.MaskedTextBox1.Location = New System.Drawing.Point(72, 190)
        Me.MaskedTextBox1.Mask = "(+27) 00 000 0000"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(336, 19)
        Me.MaskedTextBox1.TabIndex = 31
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(40, 156)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(164, 21)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Emergency Number"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(40, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(137, 21)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Primary Number"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MaskedTextBox3
        '
        Me.MaskedTextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MaskedTextBox3.BeepOnError = True
        Me.MaskedTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MaskedTextBox3.ForeColor = System.Drawing.Color.Gray
        Me.MaskedTextBox3.HidePromptOnLeave = True
        Me.MaskedTextBox3.Location = New System.Drawing.Point(72, 91)
        Me.MaskedTextBox3.Mask = "(+27) 00 000 0000"
        Me.MaskedTextBox3.Name = "MaskedTextBox3"
        Me.MaskedTextBox3.Size = New System.Drawing.Size(336, 19)
        Me.MaskedTextBox3.TabIndex = 30
        '
        'BunifuTextbox4
        '
        Me.BunifuTextbox4.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox4.BackgroundImage = CType(resources.GetObject("BunifuTextbox4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox4.ForeColor = System.Drawing.Color.Black
        Me.BunifuTextbox4.Icon = CType(resources.GetObject("BunifuTextbox4.Icon"), System.Drawing.Image)
        Me.BunifuTextbox4.Location = New System.Drawing.Point(13, 161)
        Me.BunifuTextbox4.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.BunifuTextbox4.Name = "BunifuTextbox4"
        Me.BunifuTextbox4.Size = New System.Drawing.Size(427, 64)
        Me.BunifuTextbox4.TabIndex = 15
        Me.BunifuTextbox4.text = ""
        '
        'BunifuTextbox3
        '
        Me.BunifuTextbox3.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox3.BackgroundImage = CType(resources.GetObject("BunifuTextbox3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox3.ForeColor = System.Drawing.Color.Black
        Me.BunifuTextbox3.Icon = CType(resources.GetObject("BunifuTextbox3.Icon"), System.Drawing.Image)
        Me.BunifuTextbox3.Location = New System.Drawing.Point(13, 69)
        Me.BunifuTextbox3.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.BunifuTextbox3.Name = "BunifuTextbox3"
        Me.BunifuTextbox3.Size = New System.Drawing.Size(427, 63)
        Me.BunifuTextbox3.TabIndex = 14
        Me.BunifuTextbox3.text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.BaseColor = System.Drawing.Color.White
        Me.GroupBox1.BorderColor = System.Drawing.Color.Gainsboro
        Me.GroupBox1.BorderSize = 1
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.BunifuTextbox1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.BunifuTextbox2)
        Me.GroupBox1.Controls.Add(Me.btnNext)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.LineColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(185, 124)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(481, 428)
        Me.GroupBox1.TabIndex = 44
        Me.GroupBox1.Text = "Step 1 /4"
        Me.GroupBox1.TextLocation = New System.Drawing.Point(10, 8)
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(67, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 21)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "First Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuTextbox1
        '
        Me.BunifuTextbox1.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox1.BackgroundImage = CType(resources.GetObject("BunifuTextbox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox1.ForeColor = System.Drawing.Color.Black
        Me.BunifuTextbox1.Icon = CType(resources.GetObject("BunifuTextbox1.Icon"), System.Drawing.Image)
        Me.BunifuTextbox1.Location = New System.Drawing.Point(28, 57)
        Me.BunifuTextbox1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.BunifuTextbox1.Name = "BunifuTextbox1"
        Me.BunifuTextbox1.Size = New System.Drawing.Size(380, 61)
        Me.BunifuTextbox1.TabIndex = 11
        Me.BunifuTextbox1.text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(63, 138)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 21)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Last Name"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuTextbox2
        '
        Me.BunifuTextbox2.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox2.BackgroundImage = CType(resources.GetObject("BunifuTextbox2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox2.ForeColor = System.Drawing.Color.Black
        Me.BunifuTextbox2.Icon = CType(resources.GetObject("BunifuTextbox2.Icon"), System.Drawing.Image)
        Me.BunifuTextbox2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.BunifuTextbox2.Location = New System.Drawing.Point(28, 145)
        Me.BunifuTextbox2.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.BunifuTextbox2.Name = "BunifuTextbox2"
        Me.BunifuTextbox2.Size = New System.Drawing.Size(380, 64)
        Me.BunifuTextbox2.TabIndex = 12
        Me.BunifuTextbox2.text = ""
        '
        'btnNext
        '
        Me.btnNext.AnimationHoverSpeed = 0.07!
        Me.btnNext.AnimationSpeed = 0.03!
        Me.btnNext.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnNext.BorderColor = System.Drawing.Color.Black
        Me.btnNext.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnNext.FocusedColor = System.Drawing.Color.Empty
        Me.btnNext.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnNext.ForeColor = System.Drawing.Color.White
        Me.btnNext.Image = CType(resources.GetObject("btnNext.Image"), System.Drawing.Image)
        Me.btnNext.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnNext.Location = New System.Drawing.Point(303, 253)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnNext.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnNext.OnHoverForeColor = System.Drawing.Color.White
        Me.btnNext.OnHoverImage = Nothing
        Me.btnNext.OnPressedColor = System.Drawing.Color.Black
        Me.btnNext.Size = New System.Drawing.Size(105, 100)
        Me.btnNext.TabIndex = 13
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.BaseColor = System.Drawing.Color.White
        Me.GroupBox3.BorderColor = System.Drawing.Color.Gainsboro
        Me.GroupBox3.BorderSize = 1
        Me.GroupBox3.Controls.Add(Me.btnPrevious2)
        Me.GroupBox3.Controls.Add(Me.GunaCircleButton2)
        Me.GroupBox3.Controls.Add(Me.TextBox2)
        Me.GroupBox3.Controls.Add(Me.TextBox1)
        Me.GroupBox3.Controls.Add(Me.MaskedTextBox2)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.ZipCodeTextBox)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.provinceTextBox)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.CityTextBox)
        Me.GroupBox3.Controls.Add(Me.AddressTextBox)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.LineColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(182, 101)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(475, 502)
        Me.GroupBox3.TabIndex = 46
        Me.GroupBox3.Text = "Step 3 /4"
        Me.GroupBox3.TextLocation = New System.Drawing.Point(10, 8)
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Location = New System.Drawing.Point(75, 132)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(346, 19)
        Me.TextBox2.TabIndex = 49
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Location = New System.Drawing.Point(75, 202)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(346, 19)
        Me.TextBox1.TabIndex = 47
        '
        'MaskedTextBox2
        '
        Me.MaskedTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MaskedTextBox2.ForeColor = System.Drawing.Color.Gray
        Me.MaskedTextBox2.HidePromptOnLeave = True
        Me.MaskedTextBox2.Location = New System.Drawing.Point(69, 275)
        Me.MaskedTextBox2.Mask = "0000"
        Me.MaskedTextBox2.Name = "MaskedTextBox2"
        Me.MaskedTextBox2.Size = New System.Drawing.Size(352, 19)
        Me.MaskedTextBox2.TabIndex = 21
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(64, 251)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 21)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Zip Code"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ZipCodeTextBox
        '
        Me.ZipCodeTextBox.BackColor = System.Drawing.Color.White
        Me.ZipCodeTextBox.BackgroundImage = CType(resources.GetObject("ZipCodeTextBox.BackgroundImage"), System.Drawing.Image)
        Me.ZipCodeTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ZipCodeTextBox.ForeColor = System.Drawing.Color.Black
        Me.ZipCodeTextBox.Icon = CType(resources.GetObject("ZipCodeTextBox.Icon"), System.Drawing.Image)
        Me.ZipCodeTextBox.Location = New System.Drawing.Point(13, 259)
        Me.ZipCodeTextBox.Margin = New System.Windows.Forms.Padding(37, 19, 37, 19)
        Me.ZipCodeTextBox.Name = "ZipCodeTextBox"
        Me.ZipCodeTextBox.Size = New System.Drawing.Size(423, 39)
        Me.ZipCodeTextBox.TabIndex = 19
        Me.ZipCodeTextBox.text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(70, 183)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 21)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Province"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'provinceTextBox
        '
        Me.provinceTextBox.BackColor = System.Drawing.Color.White
        Me.provinceTextBox.BackgroundImage = CType(resources.GetObject("provinceTextBox.BackgroundImage"), System.Drawing.Image)
        Me.provinceTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.provinceTextBox.ForeColor = System.Drawing.Color.Black
        Me.provinceTextBox.Icon = CType(resources.GetObject("provinceTextBox.Icon"), System.Drawing.Image)
        Me.provinceTextBox.Location = New System.Drawing.Point(17, 187)
        Me.provinceTextBox.Margin = New System.Windows.Forms.Padding(22, 13, 22, 13)
        Me.provinceTextBox.Name = "provinceTextBox"
        Me.provinceTextBox.Size = New System.Drawing.Size(423, 39)
        Me.provinceTextBox.TabIndex = 17
        Me.provinceTextBox.text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(66, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 21)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "City"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(64, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 18)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Address"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CityTextBox
        '
        Me.CityTextBox.BackColor = System.Drawing.Color.White
        Me.CityTextBox.BackgroundImage = CType(resources.GetObject("CityTextBox.BackgroundImage"), System.Drawing.Image)
        Me.CityTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CityTextBox.ForeColor = System.Drawing.Color.Black
        Me.CityTextBox.Icon = CType(resources.GetObject("CityTextBox.Icon"), System.Drawing.Image)
        Me.CityTextBox.Location = New System.Drawing.Point(17, 120)
        Me.CityTextBox.Margin = New System.Windows.Forms.Padding(13, 9, 13, 9)
        Me.CityTextBox.Name = "CityTextBox"
        Me.CityTextBox.Size = New System.Drawing.Size(423, 39)
        Me.CityTextBox.TabIndex = 15
        Me.CityTextBox.text = ""
        '
        'AddressTextBox
        '
        Me.AddressTextBox.BackColor = System.Drawing.Color.White
        Me.AddressTextBox.BackgroundImage = CType(resources.GetObject("AddressTextBox.BackgroundImage"), System.Drawing.Image)
        Me.AddressTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.AddressTextBox.ForeColor = System.Drawing.Color.Black
        Me.AddressTextBox.Icon = CType(resources.GetObject("AddressTextBox.Icon"), System.Drawing.Image)
        Me.AddressTextBox.Location = New System.Drawing.Point(17, 54)
        Me.AddressTextBox.Margin = New System.Windows.Forms.Padding(13, 9, 13, 9)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(423, 39)
        Me.AddressTextBox.TabIndex = 14
        Me.AddressTextBox.text = ""
        '
        'btnPrevious
        '
        Me.btnPrevious.AnimationHoverSpeed = 0.07!
        Me.btnPrevious.AnimationSpeed = 0.03!
        Me.btnPrevious.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPrevious.BorderColor = System.Drawing.Color.Black
        Me.btnPrevious.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrevious.FocusedColor = System.Drawing.Color.Empty
        Me.btnPrevious.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnPrevious.ForeColor = System.Drawing.Color.White
        Me.btnPrevious.Image = CType(resources.GetObject("btnPrevious.Image"), System.Drawing.Image)
        Me.btnPrevious.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnPrevious.Location = New System.Drawing.Point(13, 274)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPrevious.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnPrevious.OnHoverForeColor = System.Drawing.Color.White
        Me.btnPrevious.OnHoverImage = Nothing
        Me.btnPrevious.OnPressedColor = System.Drawing.Color.Black
        Me.btnPrevious.Size = New System.Drawing.Size(105, 100)
        Me.btnPrevious.TabIndex = 33
        '
        'GunaCircleButton2
        '
        Me.GunaCircleButton2.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton2.AnimationSpeed = 0.03!
        Me.GunaCircleButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton2.ForeColor = System.Drawing.Color.White
        Me.GunaCircleButton2.Image = CType(resources.GetObject("GunaCircleButton2.Image"), System.Drawing.Image)
        Me.GunaCircleButton2.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleButton2.Location = New System.Drawing.Point(338, 312)
        Me.GunaCircleButton2.Name = "GunaCircleButton2"
        Me.GunaCircleButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaCircleButton2.OnHoverImage = Nothing
        Me.GunaCircleButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.Size = New System.Drawing.Size(105, 100)
        Me.GunaCircleButton2.TabIndex = 50
        '
        'btnPrevious2
        '
        Me.btnPrevious2.AnimationHoverSpeed = 0.07!
        Me.btnPrevious2.AnimationSpeed = 0.03!
        Me.btnPrevious2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPrevious2.BorderColor = System.Drawing.Color.Black
        Me.btnPrevious2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrevious2.FocusedColor = System.Drawing.Color.Empty
        Me.btnPrevious2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnPrevious2.ForeColor = System.Drawing.Color.White
        Me.btnPrevious2.Image = CType(resources.GetObject("btnPrevious2.Image"), System.Drawing.Image)
        Me.btnPrevious2.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnPrevious2.Location = New System.Drawing.Point(16, 312)
        Me.btnPrevious2.Name = "btnPrevious2"
        Me.btnPrevious2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPrevious2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnPrevious2.OnHoverForeColor = System.Drawing.Color.White
        Me.btnPrevious2.OnHoverImage = Nothing
        Me.btnPrevious2.OnPressedColor = System.Drawing.Color.Black
        Me.btnPrevious2.Size = New System.Drawing.Size(105, 100)
        Me.btnPrevious2.TabIndex = 51
        '
        'GunaCircleButton1
        '
        Me.GunaCircleButton1.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton1.AnimationSpeed = 0.03!
        Me.GunaCircleButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaCircleButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.Image = CType(resources.GetObject("GunaCircleButton1.Image"), System.Drawing.Image)
        Me.GunaCircleButton1.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleButton1.Location = New System.Drawing.Point(415, 291)
        Me.GunaCircleButton1.Name = "GunaCircleButton1"
        Me.GunaCircleButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.OnHoverImage = Nothing
        Me.GunaCircleButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.Size = New System.Drawing.Size(168, 141)
        Me.GunaCircleButton1.TabIndex = 11
        Me.GunaCircleButton1.Text = "Select Customer"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.White
        Me.GroupBox4.BaseColor = System.Drawing.Color.White
        Me.GroupBox4.BorderColor = System.Drawing.Color.Gainsboro
        Me.GroupBox4.BorderSize = 1
        Me.GroupBox4.Controls.Add(Me.GunaNumeric1)
        Me.GroupBox4.Controls.Add(Me.cbxGender)
        Me.GroupBox4.Controls.Add(Me.GunaCircleButton3)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.BunifuTextbox5)
        Me.GroupBox4.Controls.Add(Me.BunifuTextbox6)
        Me.GroupBox4.Controls.Add(Me.GunaCircleButton4)
        Me.GroupBox4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.LineColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox4.Location = New System.Drawing.Point(729, 234)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(475, 428)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.Text = "Step 4 /4"
        Me.GroupBox4.TextLocation = New System.Drawing.Point(10, 8)
        '
        'GunaCircleButton3
        '
        Me.GunaCircleButton3.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton3.AnimationSpeed = 0.03!
        Me.GunaCircleButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton3.ForeColor = System.Drawing.Color.White
        Me.GunaCircleButton3.Image = CType(resources.GetObject("GunaCircleButton3.Image"), System.Drawing.Image)
        Me.GunaCircleButton3.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleButton3.Location = New System.Drawing.Point(328, 274)
        Me.GunaCircleButton3.Name = "GunaCircleButton3"
        Me.GunaCircleButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaCircleButton3.OnHoverImage = Nothing
        Me.GunaCircleButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton3.Size = New System.Drawing.Size(105, 100)
        Me.GunaCircleButton3.TabIndex = 32
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(40, 156)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 21)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Age"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(40, 58)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 21)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Gender"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuTextbox5
        '
        Me.BunifuTextbox5.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox5.BackgroundImage = CType(resources.GetObject("BunifuTextbox5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox5.ForeColor = System.Drawing.Color.Black
        Me.BunifuTextbox5.Icon = CType(resources.GetObject("BunifuTextbox5.Icon"), System.Drawing.Image)
        Me.BunifuTextbox5.Location = New System.Drawing.Point(14, 161)
        Me.BunifuTextbox5.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.BunifuTextbox5.Name = "BunifuTextbox5"
        Me.BunifuTextbox5.Size = New System.Drawing.Size(426, 64)
        Me.BunifuTextbox5.TabIndex = 15
        Me.BunifuTextbox5.text = ""
        '
        'BunifuTextbox6
        '
        Me.BunifuTextbox6.BackColor = System.Drawing.Color.White
        Me.BunifuTextbox6.BackgroundImage = CType(resources.GetObject("BunifuTextbox6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox6.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox6.Icon = CType(resources.GetObject("BunifuTextbox6.Icon"), System.Drawing.Image)
        Me.BunifuTextbox6.Location = New System.Drawing.Point(13, 68)
        Me.BunifuTextbox6.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.BunifuTextbox6.Name = "BunifuTextbox6"
        Me.BunifuTextbox6.Size = New System.Drawing.Size(427, 63)
        Me.BunifuTextbox6.TabIndex = 14
        Me.BunifuTextbox6.text = ""
        '
        'GunaCircleButton4
        '
        Me.GunaCircleButton4.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton4.AnimationSpeed = 0.03!
        Me.GunaCircleButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton4.ForeColor = System.Drawing.Color.White
        Me.GunaCircleButton4.Image = CType(resources.GetObject("GunaCircleButton4.Image"), System.Drawing.Image)
        Me.GunaCircleButton4.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleButton4.Location = New System.Drawing.Point(13, 274)
        Me.GunaCircleButton4.Name = "GunaCircleButton4"
        Me.GunaCircleButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaCircleButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton4.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaCircleButton4.OnHoverImage = Nothing
        Me.GunaCircleButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton4.Size = New System.Drawing.Size(105, 100)
        Me.GunaCircleButton4.TabIndex = 33
        '
        'cbxGender
        '
        Me.cbxGender.BackColor = System.Drawing.Color.Transparent
        Me.cbxGender.BorderRadius = 3
        Me.cbxGender.DisabledColor = System.Drawing.Color.Gray
        Me.cbxGender.ForeColor = System.Drawing.Color.Black
        Me.cbxGender.Items = New String() {"Male", "Female"}
        Me.cbxGender.Location = New System.Drawing.Point(75, 77)
        Me.cbxGender.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.cbxGender.Name = "cbxGender"
        Me.cbxGender.NomalColor = System.Drawing.Color.White
        Me.cbxGender.onHoverColor = System.Drawing.Color.Azure
        Me.cbxGender.selectedIndex = -1
        Me.cbxGender.Size = New System.Drawing.Size(346, 48)
        Me.cbxGender.TabIndex = 34
        '
        'GunaNumeric1
        '
        Me.GunaNumeric1.BaseColor = System.Drawing.Color.White
        Me.GunaNumeric1.BorderColor = System.Drawing.Color.Silver
        Me.GunaNumeric1.BorderSize = 0
        Me.GunaNumeric1.ButtonColor = System.Drawing.Color.White
        Me.GunaNumeric1.ButtonForeColor = System.Drawing.Color.Black
        Me.GunaNumeric1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.GunaNumeric1.ForeColor = System.Drawing.Color.Black
        Me.GunaNumeric1.Location = New System.Drawing.Point(70, 180)
        Me.GunaNumeric1.Maximum = CType(9999999, Long)
        Me.GunaNumeric1.Minimum = CType(0, Long)
        Me.GunaNumeric1.Name = "GunaNumeric1"
        Me.GunaNumeric1.Size = New System.Drawing.Size(358, 30)
        Me.GunaNumeric1.TabIndex = 35
        Me.GunaNumeric1.Value = CType(0, Long)
        '
        'Customer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1000, 700)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Customer"
        Me.Text = "Customer"
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents MetroTextBox7 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents GroupBox1 As Guna.UI.WinForms.GunaGroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents BunifuTextbox1 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents Label2 As Label
    Friend WithEvents BunifuTextbox2 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents GroupBox2 As Guna.UI.WinForms.GunaGroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents MaskedTextBox3 As MaskedTextBox
    Friend WithEvents BunifuTextbox4 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents BunifuTextbox3 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MaskedTextBox1 As MaskedTextBox
    Friend WithEvents GroupBox3 As Guna.UI.WinForms.GunaGroupBox
    Friend WithEvents MaskedTextBox2 As MaskedTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ZipCodeTextBox As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents Label5 As Label
    Friend WithEvents provinceTextBox As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CityTextBox As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents AddressTextBox As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents btnNext As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnNext2 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnPrevious As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnPrevious2 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents GunaCircleButton2 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents GunaCircleButton1 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents GroupBox4 As Guna.UI.WinForms.GunaGroupBox
    Friend WithEvents GunaCircleButton3 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents BunifuTextbox5 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents BunifuTextbox6 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents GunaCircleButton4 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents GunaNumeric1 As Guna.UI.WinForms.GunaNumeric
    Friend WithEvents cbxGender As Bunifu.Framework.UI.BunifuDropdown
End Class
